// Welcome To devil-cyber Editor
// (C)please write your code here:
#include<stdio.h>
int main(){
    printf("hello from c");
    return 0
}
