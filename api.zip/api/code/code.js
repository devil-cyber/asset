// Welcome To devil-cyber Editor
// (Javascript)please write your code here:
console.log("hello")
