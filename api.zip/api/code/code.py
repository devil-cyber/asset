# Welcome To devil-cyber Editor
#(Python)please write your code here:
def helloWorld():
    import os
    print(os.listdir())
    
    
helloWorld()
