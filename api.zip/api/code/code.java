// Welcome To devil-cyber Editor
// (Java)please write your code here:
// Note (Keep your java class name as 'code')


class code {
    public static void main(String[] args) {
        System.out.println("Hello, World!"); 
    }
}
