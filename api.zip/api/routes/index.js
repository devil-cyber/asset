const express = require('express');
const router = express.Router();
const homeController = require('../controller/controller');


router.get('/',homeController.home)
router.use('/api',require('./python'))
router.use('/api',require('./cpp'))
router.use('/api',require('./c'))
router.use('/api',require('./java'))
router.use('/api',require('./js'))




module.exports = router;