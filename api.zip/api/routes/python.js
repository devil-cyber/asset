const express = require('express');
const router = express.Router();
const pythonController = require('../controller/controller')

router.post('/python',pythonController.python)

module.exports = router;