const express = require('express');
const router = express.Router();
const cppController = require('../controller/controller');


router.post('/cpp',cppController.cpp)


module.exports = router