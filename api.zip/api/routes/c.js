const express = require('express');
const router = express.Router();
const cController = require('../controller/controller');

router.post('/c',cController.c)


module.exports = router;