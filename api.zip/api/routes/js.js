const express = require('express');
const router = express.Router();
const jsController = require('../controller/controller');

router.post('/js',jsController.js)


module.exports = router;