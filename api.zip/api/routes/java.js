const express = require('express');
const router = express.Router();
const javaController = require('../controller/controller');

router.post('/java',javaController.java)


module.exports = router;