const fs = require("fs");
const {c, cpp, node, python, java} = require('compile-run');
module.exports.home = (req, res) => {
  return res.send("Welcome to Home");
};

module.exports.python = async (req, res) => {
  const data = req.body.code;
  console.log(data);

  await fs.writeFile("code/code.py", data, (err) => {
    python.runFile('./code/code.py', (err, result) => {
        if(err){
            console.log(err);
            return res.send(err);
        }
        else{
            console.log(result.stdout);
            if (result.stderr!=""){
                return res.send(JSON.stringify({errorType:result.errorType, stdError:result.stderr}));
            }
            return res.send(JSON.stringify({result:result.stdout, cpuUsage:result.cpuUsage, mem:result.memoryUsage}))
        }
    });

  });
};

module.exports.cpp = async (req, res) => {
    const data = req.body.code;
    console.log(data);
  
    await fs.writeFile("code/code.cpp", data, (err) => {
      cpp.runFile('./code/code.cpp', (err, result) => {
          if(err){
              console.log(err);
              return res.send(err);
          }
          else{
              console.log(result.stdout);
              if (result.stderr!=""){
                  return res.send(JSON.stringify({errorType:result.errorType, stdError:result.stderr}));
              }
              return res.send(JSON.stringify({errorType:false,result:result.stdout, cpuUsage:result.cpuUsage, mem:result.memoryUsage}))
          }
      });
  
    });
  };
  
  module.exports.c = async (req, res) => {
    const data = req.body.code;
    console.log(data);
  
    await fs.writeFile("code/code.c", data, (err) => {
      c.runFile('./code/code.c', (err, result) => {
          if(err){
              console.log(err);
              return res.send(err);
          }
          else{
              console.log(result.stdout);
              if (result.stderr!=""){
                  return res.send(JSON.stringify({errorType:result.errorType, stdError:result.stderr}));
              }
              return res.send(JSON.stringify({errorType:false,result:result.stdout, cpuUsage:result.cpuUsage, mem:result.memoryUsage}))
          }
      });
  
    });
  };

  module.exports.java = async (req, res) => {
    const data = req.body.code;
    console.log(data);
  
    await fs.writeFile("code/code.java", data, (err) => {
        java.runFile('./code/code.java',{
            compilationPath: '/usr/lib/jvm/java-16-openjdk-amd64/bin/javac',
            executionPath: 'java'
        },(err,result)=>{
            if(err){
                console.log(err);
                return res.send(err);
            }
            else{
                if (result.stderr!=""){
                    return res.send(JSON.stringify({errorType:result.errorType, stdError:result.stderr}));
                }
                return res.send(JSON.stringify({errorType:false,result:result.stdout, cpuUsage:result.cpuUsage, mem:result.memoryUsage}))
            }
        });
  
    });
  };

  module.exports.js = async (req, res) => {
    const data = req.body.code;
    console.log(data);
  
    await fs.writeFile("code/code.js", data, (err) => {
      node.runFile('./code/code.js', (err, result) => {
          if(err){
              console.log(err);
              return res.send(err);
          }
          else{
              console.log(result);
              if (result.stderr!=""){
                  return res.send(JSON.stringify({errorType:result.errorType, stdError:result.stderr}));
              }
              return res.send(JSON.stringify({errorType:false,result:result.stdout, cpuUsage:result.cpuUsage, mem:result.memoryUsage}))
          }
      });
  
    });
  };
